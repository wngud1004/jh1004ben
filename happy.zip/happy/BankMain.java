package happy;

import java.util.Scanner;

public class BankMain {
    public static Scanner sc = new Scanner(System.in);
    private static final BankMenu dMenu = new BankMenu();

    public static void mainMenu(int bank) {
        while (true) {
            System.out.print("이용하실 서비스를 선택해주세요. \n 1.입금 \n 2.출금\n 3.잔액조회 \n 4.대출  \n(1,2,3,4 중 선택)\n>>");
            String service = sc.next();
            String menu = service.strip();

            if(menu.equals("1")) {
                dMenu.deposit(bank);
            } else if(menu.equals("2")) {
                dMenu.withdraw(bank);
            } else if(menu.equals("3")) {
                dMenu.balanceInquiry(bank);
            } else if(menu.equals("4")) {
                dMenu.loan(bank);
            } else if(menu.equals("0")) {
                System.out.println("초기화면으로 돌아갑니다.");
                break;
            } else {
                System.out.println("잘못된 입력입니다. 알맞은 정수를 입력해주세요.");
            }
        }
    }

    public static String chooseBank() {

        return null;
    }

    public static void main(String[] args) {
        String Bank = chooseBank();
        while (true) {

            System.out.println("선택하신 은행에 통장을 개설하시겠습니까?\n 1.네 | 2.아니오 \n>>");
            String choose = sc.next();
            String byn = choose.strip();
            int bank = Integer.parseInt(Bank);

            if (byn.equals("0")) break;
            if (byn.equals("1")) {dMenu.makeAccount(bank); mainMenu(bank); break; }
            else if (byn.equals("2")) {
                System.out.println("통장 개설 없이 은행 서비스를 이용하시겠습니까? \n 1.네 (은행 서비스 이용 메뉴로 이동) \n 2.아니오 (통장개설 메뉴로 이동) \n 0.종료 (시스템 종료) \n >>");
                String service = sc.next();
                String myn = service.strip();

                if (myn.equals("0")) break;
                if (myn.equals("1")) mainMenu(bank);
                else System.out.println("잘못된 입력입니다. 알맞은 정수를 입력해주세요.");
            } else System.out.println("잘못된 입력입니다. 알맞은 정수를 입력해주세요.");
        }
    }
}
