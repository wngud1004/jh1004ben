package happy;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class BankManager { //뱅크매니저 클래스, 뱅크 관리
    public final ArrayList<Bank> list;
    private final String filename;
    int result;

    public BankManager (String string) {
        filename = string;
        list = new ArrayList<>();
    }
    public void add(Bank bank) {
        list.add(bank);
    }
    public void remove(String name, String number) {
        Iterator<Bank> it = list.iterator();
        while (it.hasNext()) {
            Bank bank = it.next();
            if (bank.getName().equals(name) && bank.getAccountNumber().equals(number)) {
                it.remove();
            }
        }
    }

    public void showAll() { //전체 잔액 출력
        List<Bank> newList = list.stream().distinct().toList();
        for(Bank bank : newList) System.out.println(bank);
    }

    public void showOne(String name, String number) {
        for(Bank bank : list) {
            if (bank.getName().equals(name) && bank.getAccountNumber().equals(number)) {
                int money = bank.getPrice();
                System.out.println("현재 " + name + "님의 통장잔액은 " + money + "원 입니다");
            }
        }
    }
    public String accountNumber() {
        int accountNumber = (int) (Math.random() * 8999) + 1000;
        String number = String.valueOf(accountNumber);
        for (Bank bank : list) {
            if(!bank.getAccountNumber().equals(number)) {
                return number;
            }
        }
        return number;
    }

    public void input(int n, String name, String number, int price) {
        for(Bank bank : list) {
            if (bank.getName().equals(name) && bank.getAccountNumber().equals(number)) {
                result = bank.getPrice() + price;
                System.out.println("입금이 완료 되었습니다.");
                System.out.println("현재 " + name + "님의 통장잔액은 " + result + "원이 되었습니다");
                break;
            }
        }
        BankMenu.chooseRemove(n, name, number);
        BankMenu.chooseAdd(n, name, number, result);
    }

    public void output(int n, String name, String number, int price) {
        for(Bank bank : list) {
            if (bank.getName().equals(name) && bank.getAccountNumber().equals(number)) {
                result = bank.getPrice() - price;
                if (result > 0) {
                    System.out.println("출금이 완료 되었습니다.");
                    System.out.println("현재 " + name + "님의 통장잔액은 " + result + "원이 되었습니다");
                    BankMenu.chooseRemove(n, name, number);
                    BankMenu.chooseAdd(n, name, number, result);
                    break;
                } else if (result < 0) {
                    System.out.println("잔액이 부족합니다!");
                    System.out.println("통장 잔액보다 높은 금액을 인출하고 싶으시면 대출을 이용해주세요");
                    break;
                }
            }
        }
    }

    public void minus (int n, String name, String number, int price) {
        for(Bank bank : list) {
                if (bank.getName().equals(name) && bank.getAccountNumber().equals(number)) {
                    result = bank.getPrice() - price;
                    System.out.println("대출이 완료 되었습니다.");
                    System.out.println("현재 " + name + "님의 통장잔액은 " + result + "원이 되었습니다");
                    break;
                }
        }
        BankMenu.chooseRemove(n, name, number);
        BankMenu.chooseAdd(n, name, number, result);
    }

    public void save() { //저장하기
        try {
            FileWriter writer = new FileWriter(filename); // 파일 열기
            BufferedWriter buf = new BufferedWriter(writer);

            for (Bank bank : list) {
                buf.write(bank.getName() + ",");
                buf.write(bank.getAccountNumber() + ",");
                buf.write(bank.getPrice() + ",");
                buf.newLine();
            }
            buf.close();
        } catch (IOException e) {
            System.out.println("오류");
            //e.printStackTrace();
        }
    }

    public void load() {
        //파일읽기, 데이터 읽기, 객체 생성후 리스트 추가, 파일 닫기
        try {
            FileReader reader = new FileReader(filename); //파일 열기 파일이 없으면 오류 발생
            BufferedReader buf = new BufferedReader(reader);
            //파일에서 데이터 읽어오기
            String line;
            while ((line = buf.readLine()) != null) {
                // line = line.replace("\n", "").replace("\r", "");
                StringTokenizer tokenizer = new StringTokenizer(line, ",");
                String name = tokenizer.nextToken();
                String accountNumber = tokenizer.nextToken();
                int price = Integer.parseInt(tokenizer.nextToken());
                add(new Bank(name, accountNumber, price));
            }
            buf.close();
        } catch (FileNotFoundException e) {
            System.out.println(filename + "파일이 존재하지 않습니다.");
            //e.printStackTrace(); 흐름 보여주기
        } catch (IOException e) {
            System.out.println(filename + "파일로 부터 데이터를 읽을수 없습니다.");
            //e.printStackTrace();
        }
    }
}
