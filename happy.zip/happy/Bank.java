package happy;

public class Bank  { //Bank 클래스, 데이터 무결성 보완
    private String name;
    private String accountNumber;
    private int price;

    public Bank(String name, String accountNumber, int price) {
        this.name = name;
        this.accountNumber = accountNumber;
        this.price = price;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String toString() {
        return "이름 " + name + " 계좌번호 " + accountNumber + " 돈 " + price;
    }

    public static String[] split(String s) {
        return s.split(" ");
    }
}
