package happy;

import java.util.Scanner;

public class BankMenu  { //뱅크 메뉴 클래스, 메뉴 메소드 존재
    private static final Scanner sc = new Scanner(System.in);
    public static BankManager manager1 = new BankManager("happy\\DHB.txt");
    public static BankManager manager2 = new BankManager("happy\\SBB.txt");
    public static BankManager manager3 = new BankManager("happy\\SWB.txt");
    public static BankManager manager4 = new BankManager("happy\\JHB.txt");

    public void chooseLoad(String Bank) {
        if(Bank.equals("1")) {
            manager1.load();
        } else if(Bank.equals("2")) {
            manager2.load();
        } else if(Bank.equals("3")) {
            manager3.load();
        } else if(Bank.equals("4")) {
            manager4.load();
        } else {
            System.out.println("잘못된 입력입니다. 알맞은 숫자를 선택해주세요.");
        }
    }

    public void chooseShowAll(int n) {
        if(n == 1) {
            manager1.showAll();
        } else if(n == 2) {
            manager2.showAll();
        } else if(n == 3) {
            manager3.showAll();
        } else if(n == 4) {
            manager4.showAll();
        } else {
            System.out.println("잘못된 입력입니다. 알맞은 정수를 입력해주세요.");
        }
    }

    public void chooseSave(int n) {
        if(n == 1) {
            manager1.save();
        } else if(n == 2) {
            manager2.save();
        } else if(n == 3) {
            manager3.save();
        } else if(n == 4) {
            manager4.save();
        } else {
            System.out.println("잘못된 입력입니다. 알맞은 정수를 입력해주세요.");
        }
    }

    public static void chooseAdd(int n, String name, String accountNumber, int price) {
        if(n == 1) {
            manager1.add(new Bank(name, accountNumber, price));
        } else if(n == 2) {
            manager2.add(new Bank(name, accountNumber, price));
        } else if(n == 3) {
            manager3.add(new Bank(name, accountNumber, price));
        } else if(n == 4) {
            manager4.add(new Bank(name, accountNumber, price));
        }
    }
    public static void chooseRemove(int n, String name, String accountNumber) {
        if(n == 1) {
            manager1.remove(name, accountNumber);
        } else if(n == 2) {
            manager2.remove(name, accountNumber);
        } else if(n == 3) {
            manager3.remove(name, accountNumber);
        } else if(n == 4) {
            manager4.remove(name, accountNumber);
        }
    }

    public void chooseShowOne(int n, String name, String accountNumber) {
        if(n == 1) {
            manager1.showOne(name, accountNumber);
        } else if(n == 2) {
            manager2.showOne(name, accountNumber);
        } else if(n == 3) {
            manager3.showOne(name, accountNumber);
        } else if(n == 4) {
            manager4.showOne(name, accountNumber);
        }
    }

    public String chooseAccountNumber(int n) {
        if(n == 1) {
            return manager1.accountNumber();
        } else if(n == 2) {
            return manager2.accountNumber();
        } else if(n == 3) {
            return manager3.accountNumber();
        } else if(n == 4) {
            return manager4.accountNumber();
        } else {
            return "잘못된 숫자 입력입니다!";
        }
    }

    public void chooseInput(int n, String name, String accountNumber, int price) {
        if(n == 1) {
            manager1.input(n, name, accountNumber, price);
        } else if(n == 2) {
            manager2.input(n, name, accountNumber, price);
        } else if(n == 3) {
            manager3.input(n, name, accountNumber, price);
        } else if(n == 4) {
            manager4.input(n, name, accountNumber, price);
        }
    }

    public void chooseOutput(int n, String name, String accountNumber, int price) {
        if(n == 1) {
            manager1.output(n, name, accountNumber, price);
        } else if(n == 2) {
            manager2.output(n, name, accountNumber, price);
        } else if(n == 3) {
            manager3.output(n, name, accountNumber, price);
        } else if(n == 4) {
            manager4.output(n, name, accountNumber, price);
        }
    }

    public void chooseMinus(int n, String name, String accountNumber, int price) {
        if(n == 1) {
            manager1.minus(n, name, accountNumber, price);
        } else if(n == 2) {
            manager2.minus(n, name, accountNumber, price);
        } else if(n == 3) {
            manager3.minus(n, name, accountNumber, price);
        } else if(n == 4) {
            manager4.minus(n, name, accountNumber, price);
        }
    }

    public void makeAccount(int bank) { // 계좌 생성 메소드
        System.out.print("이름을 입력해주세요 :");
        String Name = sc.next();
        System.out.print("통장에 넣을 돈을 입력해주세요 :");
        int money = sc.nextInt();
        String number = chooseAccountNumber(bank);
        System.out.println("통장의 계좌번호 : " + number);
        String name = Name.strip();
        chooseAdd(bank, name, number, money);
        chooseSave(bank);
    }

    public void deposit(int bank) { //입금 메소드
        System.out.print("이름을 입력해주세요 :");
        String name = sc.next();
        System.out.print("계좌 번호를 입력해주세요 :");
        String number = sc.next();
        System.out.print("입금할 금액을 입력해주세요 :");
        int price = sc.nextInt();
        chooseInput(bank, name, number, price);
        chooseSave(bank);
    }
    public void withdraw(int bank) { //출금 메소드
        System.out.print("이름을 입력해주세요 :");
        String name = sc.next();
        System.out.print("계좌 번호를 입력해주세요 :");
        String number = sc.next();
        System.out.print("출금할 금액을 입력해주세요 :");
        int price = sc.nextInt();
        chooseOutput(bank, name, number, price);
        chooseSave(bank);
    }
    public void loan(int bank) { //대츨 메소드
        System.out.print("이름을 입력해주세요 :");
        String name = sc.next();
        System.out.print("계좌 번호를 입력해주세요 :");
        String number = sc.next();
        System.out.print("대출할 금액을 입력해주세요 :");
        int price = sc.nextInt();
        chooseMinus(bank, name, number, price);
        chooseSave(bank);
    }
    public void balanceInquiry(int bank) { //잔액조회 메소드
        System.out.print("이름을 입력해주세요 : ");
        String name = sc.next();
        System.out.print("계좌 번호를 입력해주세요 : ");
        String number = sc.next();
        chooseShowOne(bank, name, number);
    }
    public void delete(int bank) { //계좌 메소드
        System.out.print("이름을 입력해주세요 : ");
        String name = sc.next();
        System.out.print("계좌 번호를 입력해주세요 : ");
        String number = sc.next();
        chooseRemove(bank, name, number);
        chooseSave(bank);
    }
    public void balanceInquiry1(int bank) { // 전체 잔액조회 메소드
        chooseShowAll(bank);
    }
}
